'use strict';
/**
 * Created by tehnika on 17-Sep-15.
 */
var server = "http://localhost:8000/";

angular.module('pythonProjectsApp').constant("SERVER", server);

