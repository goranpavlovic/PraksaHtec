'use strict';

/**
 * @ngdoc function
 * @name pythonProjectsApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the pythonProjectsApp
 */
angular.module('pythonProjectsApp')
  .controller('AboutCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
